<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZDOBYWCY GÓR</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Klub zdobywców gór polskich</h1>
    </header>
    <div id="navi">
        <a href="kw1.jpg">kwerenda1</a>
        <a href="kw2.jpg">kwerenda2</a>
        <a href="kw3.jpg">kwerenda3</a>
        <a href="kw4.jpg">kwerenda4</a>
    </div>
    <div id="lewy">
        <img alt="logo zdobywcy" src="logo.jpg">
        <h3>razem z nami:</h3>
        <ul>
            <li>
                wyjazdy
            </li>
            <li>
                szkolenia
            </li>
            <li>
                rekreacja
            </li>
            <li>
                wypoczynek
            </li>
            <li>
                wyzwania
            </li>
        </ul>
    </div>
    <div id="prawy">
        <h2>Dołącz od naszego zespołu!</h2>
        <p>Wpisz swoje dane do formularza:</p>
        <form method="POST">
            <label for="Nazwisko">Nazwisko: </label>
            <input type="text" name="Nazwisko"></input>
            <label for="imie">imię: </label>
            <input type="text" name="imie"></input>
            <label for="funkcja">Funkcja: </label>
            <select name="funkcja">
            <option value="uczestnik">uczesnik</option>
            <option value="przewodnik">przewodnik</option>
            <option value="zaopatrzeniowiec">zaopatrzeniowiec</option>
            <option value="organizator">organizator</option>
            <option value="ratownik">ratownik</option>
            </select>
            <label for="email">Email: </label>
            <input type="email" name="email"></input>
            <input type="submit" value="submit"></input>
            <?php
            $p2 = mysqli_connect('localhost','root','','zdobywcy');   
            if(isset($_POST['Nazwisko']))
            {  
                $nazwisko = $_POST['Nazwisko'];
                $imie = $_POST['imie'];
                $funkcja = $_POST['funkcja'];
                $email = $_POST['email'];
                $zad = "INSERT INTO osoby VALUES (NULL,'$nazwisko','$imie','$funkcja','$email');";
                $rekord = mysqli_query($p2,$zad);
            }
            mysqli_close($p2);
            ?>
        </form>
        <table>
            <tr>
                <td>
                    Nazwisko
                </td>
                <td>
                    Imię
                </td>
                <td>
                    Funkcja
                </td>
                <td>
                    Email
                </td>
            </tr>
        <?php
        $p = mysqli_connect('localhost','root','','zdobywcy');
        $zap = "SELECT nazwisko,imie,funkcja,email FROM `osoby`;";
        $odp = mysqli_query($p,$zap);
        while ($wyn = mysqli_fetch_array($odp))
        {
            echo '<tr>';
            echo '<td>'.$wyn[0].'</td>'.'<td>'.$wyn[1].'</td>'.'<td>'.$wyn[2].'</td>'.'<td>'.$wyn[3].'</td>';
            echo '</tr>';
        }
        mysqli_close($p);
        ?>
        </table>
    </div>
    <footer>
        Stronę wykonał:
    </footer>
</body>
</html>